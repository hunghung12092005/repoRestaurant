// module.exports = {
//     devServer: {
//       host: '127.0.0.1',
//       port: 8080, // Hoặc cổng bạn muốn sử dụng
//       public: '127.0.0.1:8080', // Cổng và địa chỉ mà bạn muốn chạy
//     }
//   };