// // src/config.js
// Hùng sửa code ở trên máy tính
const a = 2;
