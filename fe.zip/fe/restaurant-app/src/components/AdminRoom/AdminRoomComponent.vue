<template>
  <div class="page-container">
    <!-- Tiêu đề trang -->
    <div class="page-header mb-4">
      <h1 class="page-title">Quản Lý Phòng</h1>
      <p class="page-subtitle">Tạo mới, chỉnh sửa và quản lý các phòng trong khách sạn.</p>
    </div>

    <!-- Thông báo -->
    <div v-if="successMessage" class="alert alert-success">{{ successMessage }}</div>
    <div v-if="errorMessage && !isLoading" class="alert alert-danger">{{ errorMessage }}</div>

    <!-- Bộ lọc và tìm kiếm -->
    <div class="card filter-card mb-4">
      <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3 col-12 col-lg-8">
          <input
            v-model="searchQuery"
            type="text"
            class="form-control"
            placeholder="Tìm số phòng, tầng, hoặc loại phòng..."
            @input="currentPage = 1"
          />
          <select v-model="filterRoomType" class="form-select" @change="currentPage = 1">
            <option value="">Tất cả loại phòng</option>
            <option v-for="type in roomTypes" :key="type.type_id" :value="type.type_id">
              {{ type.type_name }}
            </option>
          </select>
          <select v-model="filterStatus" class="form-select" @change="currentPage = 1">
            <option value="">Tất cả trạng thái</option>
            <option value="Trống">Trống</option>
            <option value="Đã đặt">Đã đặt</option>
          </select>
        </div>
        <button class="btn btn-primary ms-auto" @click="openAddModal">
          <i class="bi bi-plus-circle me-2"></i>Thêm Phòng
        </button>
      </div>
    </div>

    <!-- Bảng danh sách phòng -->
    <div class="table-container">
      <table v-if="displayedRooms.length > 0" class="table booking-table align-middle">
        <thead>
          <tr>
            <th style="width: 20%">Phòng & Tầng</th>
            <th style="width: 25%">Loại Phòng</th>
            <th style="width: 25%">Sức Chứa</th>
            <th class="text-center" style="width: 15%">Trạng Thái</th>
            <th class="text-center" style="width: 15%">Hành Động</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="room in displayedRooms" :key="room.room_id">
            <td>
              <div class="fw-bold type-name">{{ room.room_name || 'Chưa có' }}</div>
              <p class="description-text mb-0">Tầng {{ room.floor_number || 'N/A' }}</p>
            </td>
            <td>
              <div class="fw-bold">{{ room.roomType?.type_name || 'Không xác định' }}</div>
              <p class="description-text mb-0">{{ room.roomType?.description || 'Không có mô tả' }}</p>
            </td>
            <td>
              <div v-if="room.roomType" class="occupancy-info">
                <span class="me-3">
                  <i class="bi bi-people-fill me-1"></i>{{ room.roomType.max_occupancy || 0 }} Người lớn
                </span>
                <span class="me-3">
                  <i class="bi bi-people-fill me-1"></i>{{ room.roomType.max_occupancy_child || 0 }} Trẻ em
                </span>
                <span>
                  <i class="bi bi-hdd-stack-fill me-1"></i>{{ room.roomType.bed_count || 0 }} Giường
                </span>
              </div>
              <span v-else class="badge badge-secondary">Không có thông tin</span>
            </td>
            <td class="text-center">
              <span class="badge" :class="getStatusBadge(room.status)">
                {{ formatStatus(room.status) }}
              </span>
            </td>
            <td class="text-center action-buttons">
              <button class="btn btn-outline-primary btn-sm" title="Sửa" @click="openEditModal(room)">
                <i class="bi bi-pencil-fill"></i>
              </button>
              <button class="btn btn-outline-danger btn-sm" title="Xóa" @click="deleteRoom(room.room_id)">
                <i class="bi bi-trash-fill"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <div v-if="displayedRooms.length === 0 && !isLoading" class="alert alert-light text-center m-0">
        Không tìm thấy dữ liệu phòng phù hợp.
      </div>
       <div v-if="isLoading" class="d-flex justify-content-center p-4">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Đang tải...</span>
        </div>
      </div>
    </div>

    <!-- Phân trang -->
    <nav v-if="totalPages > 1" aria-label="Page navigation" class="d-flex justify-content-between align-items-center mt-4">
      <div class="text-muted">
        Hiển thị {{ displayedRooms.length }} / {{ totalItems }} phòng
      </div>
      <ul class="pagination justify-content-center mb-0">
        <li class="page-item" :class="{ disabled: currentPage === 1 }">
          <a class="page-link" href="#" @click.prevent="currentPage = 1">««</a>
        </li>
        <li class="page-item" :class="{ disabled: currentPage === 1 }">
          <a class="page-link" href="#" @click.prevent="currentPage--">«</a>
        </li>
        <li v-for="page in pageRange" :key="page" class="page-item" :class="{ active: page === currentPage }">
          <a class="page-link" href="#" @click.prevent="currentPage = page">{{ page }}</a>
        </li>
        <li class="page-item" :class="{ disabled: currentPage === totalPages }">
          <a class="page-link" href="#" @click.prevent="currentPage++">»</a>
        </li>
        <li class="page-item" :class="{ disabled: currentPage === totalPages }">
          <a class="page-link" href="#" @click.prevent="currentPage = totalPages">»»</a>
        </li>
      </ul>
    </nav>

    <!-- Modal thêm/sửa phòng -->
    <div v-if="isModalOpen" class="modal-backdrop fade show"></div>
    <div v-if="isModalOpen" class="modal fade show d-block" tabindex="-1">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content modal-custom">
          <div class="modal-header modal-header-custom">
            <h5 class="modal-title">{{ currentRoom ? 'Cập nhật Phòng' : 'Thêm Phòng Mới' }}</h5>
            <button type="button" class="btn-close" @click="closeModal" aria-label="Close"></button>
          </div>
          <div class="modal-body p-4">
            <div v-if="modalErrorMessage" class="alert alert-warning">{{ modalErrorMessage }}</div>
            <form @submit.prevent="saveRoom">
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Số Phòng</label>
                  <input type="text" v-model.trim="form.room_name" @input="onInputRoomName" class="form-control" required placeholder="Nhập số phòng (VD: 101)" :class="{ 'is-invalid': errors.room_name }"/>
                   <div v-if="errors.room_name" class="invalid-feedback">{{ errors.room_name }}</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Tầng</label>
                  <input type="number" v-model.number="form.floor_number" @input="onInputFloorNumber" class="form-control" required min="1" placeholder="Nhập số tầng" :class="{ 'is-invalid': errors.floor_number }"/>
                   <div v-if="errors.floor_number" class="invalid-feedback">{{ errors.floor_number }}</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Loại Phòng</label>
                  <select v-model="form.type_id" class="form-select" required :class="{ 'is-invalid': errors.type_id }">
                    <option value="">-- Chọn loại phòng --</option>
                    <option v-for="type in roomTypes" :key="type.type_id" :value="type.type_id">
                      {{ type.type_name }}
                    </option>
                  </select>
                   <div v-if="errors.type_id" class="invalid-feedback">{{ errors.type_id }}</div>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Trạng Thái</label>
                  <select v-model="form.status" class="form-select" required :class="{ 'is-invalid': errors.status }">
                    <option value="">-- Chọn trạng thái --</option>
                    <option value="Trống">Trống</option>
                    <option value="Đã đặt">Đã đặt</option>
                  </select>
                   <div v-if="errors.status" class="invalid-feedback">{{ errors.status }}</div>
                </div>
                <div class="col-12">
                  <label class="form-label">Mô Tả</label>
                  <textarea v-model="form.description" @input="onInputDescription" class="form-control" rows="3" placeholder="Nhập mô tả phòng"></textarea>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer modal-footer-custom">
            <button type="button" class="btn btn-secondary" @click="closeModal" :disabled="isLoading">Hủy</button>
            <button type="button" class="btn btn-primary" @click="saveRoom" :disabled="isLoading">
              <span v-if="isLoading" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
              Lưu Lại
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue';
import axios from 'axios';

// Cấu hình API client
const apiClient = axios.create({
  baseURL: 'http://127.0.0.1:8000/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
});

// State
const rooms = ref([]);
const roomTypes = ref([]);
const searchQuery = ref('');
const filterRoomType = ref('');
const filterStatus = ref('');
const isModalOpen = ref(false);
const isLoading = ref(false);
const currentRoom = ref(null);
const successMessage = ref('');
const errorMessage = ref('');
const modalErrorMessage = ref('');
const currentPage = ref(1);
const itemsPerPage = ref(10);
const totalItems = ref(0);
const form = ref({
  room_name: '',
  type_id: '',
  floor_number: 1,
  status: 'Trống',
  description: ''
});
const errors = ref({
  room_name: '',
  type_id: '',
  floor_number: '',
  status: ''
});

// Fetch data
const fetchRooms = async (page = 1) => {
  isLoading.value = true;
  errorMessage.value = '';
  try {
    const response = await apiClient.get(`/rooms?page=${page}&per_page=${itemsPerPage.value}`);
    console.log('Rooms API response:', JSON.stringify(response.data, null, 2));
    if (Array.isArray(response.data.data)) {
      rooms.value = response.data.data.map(room => ({
        ...room,
        // *** GIỮ NGUYÊN LOGIC CŨ ***
        roomType: room.room_type || { type_name: 'N/A' } 
      }));
    } else {
      rooms.value = [];
    }
    totalItems.value = response.data.total || 0;
    currentPage.value = response.data.current_page || 1;
  } catch (error) {
    console.error('Fetch rooms error:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status
    });
    errorMessage.value = error.response?.data?.message || 'Không thể tải danh sách phòng.';
    rooms.value = [];
    totalItems.value = 0;
  } finally {
    isLoading.value = false;
  }
};

const fetchRoomTypes = async () => {
  try {
    const response = await apiClient.get('/room-types');
    console.log('RoomTypes API response:', JSON.stringify(response.data, null, 2));
    roomTypes.value = Array.isArray(response.data.data) ? response.data.data : [];
    if (roomTypes.value.length === 0) {
      errorMessage.value = 'Không tìm thấy loại phòng nào. Vui lòng thêm loại phòng trước.';
    }
  } catch (error) {
    console.error('Fetch room types error:', error);
    errorMessage.value = error.response?.data?.message || 'Không thể tải danh sách loại phòng.';
    roomTypes.value = [];
  }
};

// Initialize data
onMounted(async () => {
  isLoading.value = true;
  try {
    await Promise.all([fetchRooms(), fetchRoomTypes()]);
  } catch (error) {
    console.error('Error initializing data:', error);
    errorMessage.value = 'Khởi tạo dữ liệu thất bại.';
  } finally {
    isLoading.value = false;
  }
});

// Watch for page changes
watch(currentPage, (newPage) => {
  fetchRooms(newPage);
});

// Filter rooms
const filteredRooms = computed(() => {
  if (!Array.isArray(rooms.value)) return [];
  return rooms.value.filter(room => {
    const roomName = room.room_name?.toLowerCase() || '';
    const typeName = room.roomType?.type_name?.toLowerCase() || '';
    const floorNumber = room.floor_number?.toString() || '';
    const matchesSearch = roomName.includes(searchQuery.value.toLowerCase()) ||
                         typeName.includes(searchQuery.value.toLowerCase()) ||
                         floorNumber.includes(searchQuery.value.toLowerCase());
    const matchesRoomType = !filterRoomType.value || room.type_id == parseInt(filterRoomType.value);
    const statusMapping = {
      'available': 'Trống',
      'occupied': 'Đã đặt',
      'pending_cancel': 'Đang chờ hủy'
    };
    const displayStatus = statusMapping[room.status] || room.status;
    const matchesStatus = !filterStatus.value || displayStatus === filterStatus.value;
    return matchesSearch && matchesRoomType && matchesStatus;
  });
});

// Pagination
const totalPages = computed(() => Math.ceil(totalItems.value / itemsPerPage.value));

const displayedRooms = computed(() => {
  // Logic lọc giờ đã được chuyển lên filteredRooms
  return filteredRooms.value;
});

// *** THAY ĐỔI: Sử dụng pageRange từ script cũ ***
const pageRange = computed(() => {
  const maxPages = 5;
  let start = Math.max(1, currentPage.value - Math.floor(maxPages / 2));
  let end = Math.min(totalPages.value, start + maxPages - 1);
  if (end - start + 1 < maxPages) {
    start = Math.max(1, end - maxPages + 1);
  }
  return Array.from({ length: end - start + 1 }, (_, i) => start + i);
});

// Modal actions
const openAddModal = () => {
  form.value = {
    room_name: '',
    type_id: '',
    floor_number: 1,
    status: 'Trống',
    description: ''
  };
  errors.value = {};
  currentRoom.value = null;
  isModalOpen.value = true;
  successMessage.value = '';
  modalErrorMessage.value = '';
  console.log('Opened add modal, form reset:', { ...form.value });
};

const openEditModal = (room) => {
  console.log('Opening edit modal for room:', JSON.stringify(room, null, 2));
  if (!room || typeof room !== 'object') {
    console.error('Invalid room data:', room);
    return;
  }
  const statusMapping = {
    'available': 'Trống',
    'occupied': 'Đã đặt',
    'pending_cancel': 'Đang chờ hủy'
  };
  form.value = {
    room_name: String(room.room_name || ''),
    type_id: String(room.type_id || ''),
    floor_number: Number(room.floor_number) || 1,
    status: statusMapping[room.status] || 'Trống',
    description: String(room.description || '')
  };
  currentRoom.value = { ...room };
  isModalOpen.value = true;
  errors.value = {};
  successMessage.value = '';
  modalErrorMessage.value = '';
  console.log('Edit modal opened, form set:', { ...form.value });
};

const closeModal = () => {
  isModalOpen.value = false;
  errors.value = {};
  modalErrorMessage.value = '';
  currentRoom.value = null;
  form.value = {
    room_name: '',
    type_id: '',
    floor_number: 1,
    status: 'Trống',
    description: ''
  };
  console.log('Closed modal, form reset:', { ...form.value });
};

// Handle inputs
const onInputRoomName = (event) => {
  form.value.room_name = event.target.value;
  errors.value.room_name = '';
  modalErrorMessage.value = '';
  console.log('Room name input:', form.value.room_name);
};

const onInputFloorNumber = (event) => {
  form.value.floor_number = Number(event.target.value) || 1;
  errors.value.floor_number = '';
  modalErrorMessage.value = '';
  console.log('Floor number input:', form.value.floor_number);
};

const onInputDescription = (event) => {
  form.value.description = event.target.value;
  console.log('Description input:', form.value.description);
};

// Form validation
const validateForm = () => {
  errors.value = {};
  let isValid = true;

  if (!form.value.room_name || form.value.room_name.trim().length === 0) {
    errors.value.room_name = 'Vui lòng nhập số phòng';
    isValid = false;
  }
  if (!form.value.type_id) {
    errors.value.type_id = 'Vui lòng chọn loại phòng';
    isValid = false;
  }
  if (!form.value.floor_number || form.value.floor_number < 1) {
    errors.value.floor_number = 'Tầng phải lớn hơn 0';
    isValid = false;
  }
  if (!['Trống', 'Đã đặt'].includes(form.value.status)) {
    errors.value.status = 'Vui lòng chọn trạng thái hợp lệ';
    isValid = false;
  }

  console.log('Validation result:', { isValid, form: { ...form.value }, errors: errors.value });
  return isValid;
};

// Save room
const saveRoom = async () => {
  console.log('Form data before validation:', { ...form.value });
  if (!validateForm()) {
    modalErrorMessage.value = 'Vui lòng kiểm tra thông tin nhập.';
    return;
  }

  isLoading.value = true;
  modalErrorMessage.value = '';
  const statusMapping = {
    'Trống': 'available',
    'Đã đặt': 'occupied',
    'Đang chờ hủy': 'pending_cancel'
  };
  const payload = {
    room_name: form.value.room_name.trim(),
    type_id: form.value.type_id,
    floor_number: form.value.floor_number,
    status: statusMapping[form.value.status] || 'available',
    description: form.value.description.trim() || null
  };
  console.log('Sending POST/PUT data:', payload);
  try {
    let response;
    if (currentRoom.value) {
      response = await apiClient.put(`/rooms/${currentRoom.value.room_id}`, payload);
      console.log('PUT response:', JSON.stringify(response.data, null, 2));
      const index = rooms.value.findIndex(r => r.room_id === currentRoom.value.room_id);
      if (index !== -1) {
        // *** GIỮ NGUYÊN LOGIC CŨ ***
        rooms.value[index] = { ...response.data.data, roomType: response.data.data.room_type || { type_name: 'N/A' } }; 
      }
      successMessage.value = 'Cập nhật phòng thành công!';
    } else {
      response = await apiClient.post('/rooms', payload);
      console.log('POST response:', JSON.stringify(response.data, null, 2));
      // *** GIỮ NGUYÊN LOGIC CŨ ***
      rooms.value.push({ ...response.data.data, roomType: response.data.data.room_type || { type_name: 'N/A' } }); 
      fetchRooms(currentPage.value);
      successMessage.value = 'Thêm phòng thành công!';
    }
    closeModal();
  } catch (error) {
    console.error('Save room error:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status
    });
    modalErrorMessage.value = error.response?.data?.message || 'Lưu phòng thất bại.';
    if (error.response?.status === 422) {
      const backendErrors = error.response.data?.errors || {};
      errors.value = { ...backendErrors };
      modalErrorMessage.value += ': ' + Object.values(backendErrors).flat().join(', ');
    }
  } finally {
    isLoading.value = false;
  }
};

// Delete room
const deleteRoom = async (room_id) => {
  if (!confirm('Bạn có chắc chắn muốn xóa phòng này?')) return;

  isLoading.value = true;
  errorMessage.value = '';
  try {
    await apiClient.delete(`/rooms/${room_id}`);
    rooms.value = rooms.value.filter(r => r.room_id !== room_id);
    if (displayedRooms.value.length === 0 && currentPage.value > 1) {
      currentPage.value--;
    }
    successMessage.value = 'Xóa phòng thành công!';
    fetchRooms(currentPage.value);
  } catch (error)
 {
    console.error('Delete room error:', error);
    errorMessage.value = error.response?.data?.message || 'Xóa phòng thất bại.';
  } finally {
    isLoading.value = false;
  }
};

// --- *** THÊM CÁC HÀM TIỆN ÍCH MÀ TEMPLATE MỚI CẦN *** ---
const formatStatus = (status) => {
  const map = { available: 'Trống', occupied: 'Đã đặt', maintenance: 'Bảo trì' };
  return map[status] || status;
};

const getStatusBadge = (status) => {
  const map = {
    available: 'badge-success',
    occupied: 'badge-danger',
    maintenance: 'badge-warning',
  };
  return map[status] || 'badge-secondary';
};
</script>


<style scoped>
/* Copied styles from AdminRoomTypeComponent */
@import url('https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@300;400;500;600;700&display=swap');
@import url('https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css');

.page-container {
  font-family: 'Be Vietnam Pro', sans-serif;
  background-color: #f4f7f9;
  padding: 2rem;
  color: #34495e;
}
.page-header {
  border-bottom: 1px solid #e5eaee;
  padding-bottom: 1rem;
}
.page-title {
  font-size: 2rem;
  font-weight: 700;
}
.page-subtitle {
  font-size: 1rem;
  color: #7f8c8d;
}
.filter-card {
  background-color: #ffffff;
  border: none;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}
.form-control,
.form-select {
  border-radius: 8px;
  border: 1px solid #e5eaee;
  transition: all 0.2s ease-in-out;
  font-size: 0.9rem;
}
.form-control:focus,
.form-select:focus {
  border-color: #3498db;
  box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.15);
}

.table-container {
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
  overflow-x: auto;
}
.booking-table {
  font-size: 0.875rem;
  border-collapse: separate;
  border-spacing: 0;
  min-width: 900px;
}
.booking-table thead th {
  background-color: #f8f9fa;
  color: #7f8c8d;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  border-bottom: 2px solid #e5eaee;
  padding: 1rem;
  white-space: nowrap;
}
.booking-table td {
  padding: 1.25rem 1rem;
  border-bottom: 1px solid #e5eaee;
}
.booking-table tbody tr:last-child td {
  border-bottom: none;
}
.booking-table tbody tr:hover {
  background-color: #f9fafb;
}
.type-name {
  font-size: 1rem;
}
.description-text {
  font-size: 0.8rem;
  color: #7f8c8d;
  max-width: 250px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.occupancy-info {
  white-space: nowrap;
  font-size: 0.85rem;
  color: #34495e;
}
.occupancy-info .bi {
  color: #7f8c8d;
}

.badge {
  padding: 0.4em 0.8em;
  font-size: 0.75rem;
  font-weight: 600;
  border-radius: 20px;
  letter-spacing: 0.5px;
}
.badge-secondary { background-color: #f3f4f6; color: #7f8c8d; }
.badge-success { background-color: #e6f9f0; color: #2ecc71; }
.badge-danger { background-color: #fce8e6; color: #e74c3c; }
.badge-warning { background-color: #fef5e7; color: #f39c12; }


.action-buttons {
  white-space: nowrap;
}
.action-buttons .btn {
  margin: 0 2px;
}

.pagination .page-link {
  border: none;
  border-radius: 8px;
  margin: 0 4px;
  color: #7f8c8d;
  font-weight: 600;
}
.pagination .page-item.active .page-link {
  background-color: #3498db;
  color: white;
}

.modal-backdrop {
  background-color: rgba(0, 0, 0, 0.4);
}
.modal-custom {
  border-radius: 16px;
  border: none;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}
.modal-header-custom {
  background-color: #f4f7f9;
  border-bottom: 1px solid #e5eaee;
  padding: 1.5rem;
}
.modal-footer-custom {
  background-color: #f4f7f9;
  border-top: 1px solid #e5eaee;
  padding: 1rem 1.5rem;
}
</style>