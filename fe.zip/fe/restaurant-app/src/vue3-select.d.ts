// declare module 'vue3-select' {
//     import { DefineComponent } from 'vue';
//     const Vue3Select: DefineComponent;
//     export default Vue3Select;
//   }