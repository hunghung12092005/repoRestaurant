<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use Endroid\QrCode\QrCode; // Thêm dòng này để sử dụng thư viện QR Code
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\ErrorCorrectionLevel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        // Xác thực dữ liệu nhập vào
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
            'turnstileResponse' => 'required|string', // Thêm trường Turnstile
        ]);

        // Xác thực Turnstile
        $secretKey = '0x4AAAAAABhcDUvzGTo0A_uUgpVVQMk8wIc';
        $response = Http::asForm()->post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'secret' => $secretKey,
            'response' => $request->turnstileResponse,
        ]);

        $result = json_decode($response->body());

        if (!$result->success) {
            return response()->json(['error' => 'Turnstile verification failed.'], 400);
        }

        // Kiểm tra thông tin xác thực và lấy token
        $credentials = $request->only('email', 'password');

        if (!$token = JWTAuth::attempt($credentials)) {
            return response()->json(['message' => 'Sai tai khoan hoac mat khau'], 401);
        }

        $user = Auth::user();
        return response()->json([
            'message' => 'Login successful',
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
            ]
        ]);
    }
    public function register(Request $request)
    {
        // Xác thực dữ liệu nhập vào
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6',
        ]);

        // Kiểm tra xem email đã tồn tại hay chưa
        if (User::where('email', $request->email)->exists()) {
            return response()->json(['error' => 'Đã tồn tại email.'], 409); // 409 Conflict
        }

        $role = 'client';

        // Tạo người dùng mới
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'role' => $role,
            'password' => bcrypt($request->password), // Mã hóa mật khẩu
            'qr_code' => null, // Đặt giá trị mặc định là null
        ]);

        // Tạo token cho người dùng vừa đăng ký
        $token = JWTAuth::fromUser($user);
        // Tạo mã QR
        //$qrCode = new QrCode('https://api.hxhhotel.online/qr-login?token=' . $token);

        // Tạo writer để xuất mã QR
       // $writer = new PngWriter();
        //$dataUri = $writer->write($qrCode)->getDataUri();
        // Lưu mã QR vào cơ sở dữ liệu
        //$user->qr_code = $dataUri; // Lưu mã QR
        //$user->save();
        // Trả về thông tin người dùng và mã QR
        return response()->json([
            'message' => 'Đăng ký thành công',
            'token' => $token,
            'user' => $user,
            //'qr_code' => $dataUri, // Trả về mã QR dưới dạng URI
        ], 201);
    }
    //lấy token về
    public function someProtectedRoute(Request $request)
    {
        try {
            // Xác thực token và lấy thông tin người dùng
            $user = JWTAuth::parseToken()->authenticate();

            // Xử lý yêu cầu với thông tin người dùng
            return response()->json(['user' => $user]);
        } catch (\Exception $e) {
            // Token không hợp lệ hoặc hết hạn
            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }
    //login bằng mã QR
    public function qrLogin(Request $request)
    {
        // Kiểm tra xem có token trong yêu cầu
        if (!$request->has('token')) {
            return response()->json(['error' => 'Token không được cung cấp.'], 400);
        }

        $token = $request->input('token');

        try {
            // Xác thực token và lấy thông tin người dùng
            $user = JWTAuth::setToken($token)->authenticate();

            if ($user) {
                // Token hợp lệ, trả về thông tin người dùng và token mới
                $jwtToken = JWTAuth::fromUser($user);
                return response()->json([
                    'success' => true,
                    'message' => 'Đăng nhập thành công',
                    'token' => $jwtToken,
                    'user' => [
                        'id' => $user->id, // Lấy ID từ đối tượng người dùng
                        'name' => $user->name,
                        'role' => $user->role,
                    ],
                ]);
            } else {
                return response()->json(['error' => 'Người dùng không tồn tại.'], 404);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'Token không hợp lệ.'], 401);
        }
    }
    
    //quên mk
    public function sendOtp(Request $request)
    {
        $request->validate(['email' => 'required|email']);
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['success' => false, 'message' => 'Không tìm thấy tài khoản.'], 404);
        }

        // Tạo và lưu mã OTP
        $otp = rand(100000, 999999);
        $user->password_reset_token = $otp;
        $user->save();

        // Gửi email chứa mã OTP
        Mail::send('email.otp', ['otp' => $otp], function ($message) use ($user) {
            $message->to($user->email)->subject('Mã OTP để đặt lại mật khẩu');
        });

        return response()->json(['success' => true, 'message' => 'Mã OTP đã được gửi.']);
    }

    public function verifyOtp(Request $request)
    {
        $request->validate(['otp' => 'required', 'email' => 'required|email']);
        $user = User::where('email', $request->email)->first();

        if (!$user || $request->otp !== $user->password_reset_token) {
            return response()->json(['success' => false, 'message' => 'Mã OTP không chính xác.'], 400);
        }

        return response()->json(['success' => true, 'message' => 'Mã OTP xác thực thành công.']);
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'new_password' => 'required|min:6|confirmed',
        ]);

        $user = User::where('email', $request->email)->first();

        if ($user) {
            $user->password = bcrypt($request->new_password);
            $user->password_reset_token = null; // Đặt lại token
            $user->save();

            return response()->json(['success' => true, 'message' => 'Đặt lại mật khẩu thành công!']);
        }

        return response()->json(['success' => false, 'message' => 'Không tìm thấy tài khoản.'], 400);
    }
    public function changePassword(Request $request)
    {
        // Lấy ID từ token JWT
        $sub = JWTAuth::parseToken()->getPayload()->get('sub');

        // Tìm người dùng theo ID
        $user = User::find($sub);

        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // Kiểm tra dữ liệu đầu vào
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|confirmed',
        ]);

        // Kiểm tra mật khẩu hiện tại
        if (!Hash::check($request->current_password, $user->password)) {
            return response()->json(['message' => 'Current password is incorrect'], 400);
        }

        // Cập nhật mật khẩu mới
        $user->password = Hash::make($request->new_password);
        $user->save();

        return response()->json(['message' => 'Password changed successfully'], 200);
    }
    public function updateProfile(Request $request)
    {
        // Lấy ID từ token JWT
        $sub = JWTAuth::parseToken()->getPayload()->get('sub');

        // Tìm người dùng theo ID
        $user = User::find($sub);

        if (!$user) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        // Kiểm tra dữ liệu đầu vào
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $user->id,
            // Thêm các trường cần thiết khác
        ]);

        // Cập nhật thông tin hồ sơ
        $user->name = $request->name;
        $user->email = $request->email;
        // Cập nhật thêm các trường khác nếu cần

        $user->save();

        return response()->json(['message' => 'Profile updated successfully'], 200);
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
